<?php
namespace certification\ysface\controller;

use app\home\controller\BaseController;
use certification\ysface\logic\YsfaceLogic;

/**
 * 实名认证状态轮询。
 * URL: /certification/ysface/index/status?certify_id=xxx&type=person
 * 返回 code=1 通过、code=2 不通过、code=4 继续等；JS 看到 1/2 就停并刷新页面。
 */
class IndexController extends BaseController
{
    public function status()
    {
        $param = $this->request->param();
        $cid   = trim((string)($param['certify_id'] ?? ''));
        $type  = (string)($param['type'] ?? 'person');
        // 实名认证路由没有登录中间件，只能从页面带的 client_id 拿人；
        // 下面再用客户资料表的 certify_id 绑一次，防止拿别人的单刷自己的认证。
        $clientId = (int)($param['client_id'] ?? 0);

        if ($cid === '' || $clientId <= 0 || $type !== 'person') {
            return json(['status' => 200, 'msg' => '请求成功', 'code' => 4]);
        }

        $personCls = 'addon\\idcsmart_certification\\model\\CertificationPersonModel';
        if (class_exists($personCls)) {
            $person = (new $personCls())->where('client_id', $clientId)->find();
            $bound  = $person ? trim((string)($person['certify_id'] ?? '')) : '';
            if ($bound !== '' && $bound !== $cid) {
                return json(['status' => 200, 'msg' => '认证信息不匹配', 'code' => 4]);
            }
        }

        $logic = new YsfaceLogic();
        $v = $logic->verdict($logic->query($cid));

        // 站上暂时连不上 / 还没做完：把系统记录写成「2 但 refresh=0」。
        // V10 验证页只有看到 code=2 且 refresh=0 才继续轮询；
        // 记录一直停在 4 的话，验证页会当成「已提交资料」直接跳走。
        if ($v['state'] === 'wait' || $v['state'] === 'error') {
            $this->pending($logic, $clientId, $cid);
            return json(['status' => 200, 'msg' => '请求成功', 'code' => 4]);
        }

        $msg = (string)$v['msg'];

        if ($v['state'] === 'pass') {
            hook('update_certification_person', [
                'client_id' => $clientId,
                'status'    => 1,
                'auth_fail' => '',
                'refresh'   => 1,
            ]);
            session('ysface_check_id', null);
            session('ysface_active', null);
            return json(['status' => 200, 'msg' => '请求成功', 'code' => 1]);
        }

        // fail：人对不上 / 比对没完成 / 活体没过 / 核验超时 / 单号不存在
        hook('update_certification_person', [
            'client_id' => $clientId,
            'status'    => 2,
            'auth_fail' => '人脸实名核验：' . ($msg !== '' ? $msg : '认证未通过'),
            'refresh'   => 1,
        ]);
        session('ysface_check_id', null);
        session('ysface_active', null);
        return json(['status' => 200, 'msg' => '请求成功', 'code' => 2]);
    }

    /**
     * 还没出结论时的系统记录：status=2 + refresh=0。
     * V10 的验证页把这个组合当「继续等」，不会跳「已提交资料」。
     */
    private function pending(YsfaceLogic $logic, int $clientId, string $cid): void
    {
        $logic->markPending(
            $clientId,
            $cid,
            "实名认证方式:人脸活体实名核验;\r\n认证单号:{$cid};\r\n"
        );
    }
}
