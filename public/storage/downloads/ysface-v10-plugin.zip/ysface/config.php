<?php
/*
 * 后台实名认证接口配置
 */
return [
    'module_name' => [
        'title' => '名称',
        'type'  => 'text',
        'value' => '人脸活体实名核验',
        'tip'   => '接口列表里显示的名称',
        'size'  => 200,
    ],
    'api_url' => [
        'title' => '接口地址',
        'type'  => 'text',
        'value' => '',
        'tip'   => '单人版分发站地址，例如 https://face.example.com。带二级目录要写全，不要带结尾斜杠。',
        'size'  => 200,
    ],
    'api_id' => [
        'title' => 'AppID',
        'type'  => 'text',
        'value' => '',
        'tip'   => '分发站「接口」页签里的 AppID（请求头 X-App-Id）。',
        'size'  => 120,
    ],
    'api_key' => [
        'title' => 'AppKey',
        'type'  => 'text',
        'value' => '',
        'tip'   => '分发站「接口」页签里的 AppKey（请求头 X-App-Key）。',
        'size'  => 120,
    ],
    'free' => [
        'title' => '免费认证次数',
        'type'  => 'text',
        'value' => 0,
        'tip'   => '免费认证次数',
    ],
    'amount' => [
        'title' => '金额',
        'type'  => 'text',
        'value' => 0,
        'tip'   => '支付金额',
    ],
];
