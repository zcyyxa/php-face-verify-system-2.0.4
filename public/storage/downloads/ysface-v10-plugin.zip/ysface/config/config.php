<?php
/*
 * 默认配置。后台保存过的值会覆盖这里。
 */
return [
    'api_url' => '',
    'api_id'  => '',
    'api_key' => '',
];
