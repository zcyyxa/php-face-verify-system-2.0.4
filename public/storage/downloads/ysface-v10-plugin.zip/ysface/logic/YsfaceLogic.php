<?php
namespace certification\ysface\logic;

use certification\ysface\Ysface;

/**
 * 跟单人版分发站说话的唯一出处。
 * 只走 v4 接口：X-App-Id / X-App-Key，表单编码；发起拿 order_no + verify_url。
 */
class YsfaceLogic
{
    private $config;

    public function __construct()
    {
        $this->config = (new Ysface())->Config();
    }

    /** 发起活体，拿 order_no + verify_url。 */
    public function start(string $name, string $idcard): array
    {
        $r = $this->api('api/v4/face_start', ['name' => $name, 'idcard' => $idcard]);
        if (empty($r['ok'])) {
            return ['ok' => false, 'msg' => (string)$r['msg']];
        }
        $j = $r['json'];
        $code = (int)($j['code'] ?? 0);
        $d = (isset($j['data']) && is_array($j['data'])) ? $j['data'] : [];
        $order = trim((string)($d['order_no'] ?? ''));
        $live  = trim((string)($d['verify_url'] ?? ''));
        if ($code !== 200 || $order === '' || $live === '') {
            return ['ok' => false, 'msg' => (string)($j['msg'] ?? '采集页没拉起来，稍后再试。')];
        }
        return ['ok' => true, 'order_no' => $order, 'verify_url' => $live, 'json' => $j];
    }

    /** 查询结果，原样把站上的 JSON + HTTP 状态交给控制器翻译。 */
    public function query(string $orderNo): array
    {
        return $this->api('api/v4/face_query', ['order_no' => $orderNo]);
    }

    /**
     * 把 v4 查询结果翻成四种状态：
     *   pass  —— data.passed=1
     *   fail  —— data.passed=0，或这一单已经没法再查（404 单号不存在 / 504 超时 / 502 上游出错）
     *   wait  —— 503 结果没出来
     *   error —— 连不上、服务端回的不认识；保留单子，下一轮再问
     */
    public function verdict(array $r): array
    {
        $http = (int)($r['http'] ?? 0);
        $msg  = trim((string)($r['msg'] ?? ''));

        if (empty($r['ok'])) {
            if ($http === 503) {
                return ['state' => 'wait', 'msg' => $msg === '' ? '认证中，请稍后再查...' : $msg];
            }
            if (in_array($http, [404, 502, 504], true)) {
                return ['state' => 'fail', 'msg' => $msg];
            }
            return ['state' => 'error', 'msg' => $msg];
        }

        $j      = isset($r['json']) && is_array($r['json']) ? $r['json'] : [];
        $data   = isset($j['data']) && is_array($j['data']) ? $j['data'] : [];
        $passed = array_key_exists('passed', $data) ? (int)$data['passed'] : -1;
        $say    = trim((string)($data['message'] ?? ($j['msg'] ?? '')));
        if ($say === '') {
            $say = $msg;
        }
        if ($passed === 1) {
            return ['state' => 'pass', 'msg' => $say];
        }
        if ($passed === 0) {
            return ['state' => 'fail', 'msg' => $say];
        }
        return ['state' => 'wait', 'msg' => $say === '' ? '认证中，请完成人脸采集...' : $say];
    }

    /**
     * 还没出结论时写系统记录：
     *   - 认证日志写 status=2 + refresh=0（V10 验证页只认这个组合「继续等」）；
     *   - 客户实名资料写 status=4（状态页显示「待审核」，不是「未通过」）。
     */
    public function markPending(int $clientId, string $checkId, string $notes = ''): void
    {
        hook('update_certification_person', [
            'client_id'  => $clientId,
            'status'     => 2,
            'auth_fail'  => '',
            'certify_id' => $checkId,
            'notes'      => $notes,
            'refresh'    => 0,
        ]);

        $cls = 'addon\\idcsmart_certification\\model\\CertificationPersonModel';
        if (class_exists($cls)) {
            try {
                (new $cls())->where('client_id', $clientId)->update([
                    'status'      => 4,
                    'update_time' => time(),
                ]);
            } catch (\Throwable $e) {
                // 资料表写不进去不影响这次轮询；日志那边的 2/0 才是验证页看的
            }
        }
    }

    private function api(string $path, array $fields): array
    {
        $base = rtrim(trim((string)($this->config['api_url'] ?? '')), '/');
        $id   = trim((string)($this->config['api_id'] ?? ''));
        $key  = trim((string)($this->config['api_key'] ?? ''));
        if ($base === '' || $id === '' || $key === '') {
            return ['ok' => false, 'msg' => '核验服务还没配置好（接口地址 / 密钥），联系管理员。'];
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $base . '/' . $path);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded',
            'X-App-Id: ' . $id,
            'X-App-Key: ' . $key,
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);

        $body = curl_exec($ch);
        $err  = (string)curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $err !== '') {
            return ['ok' => false, 'http' => 0, 'json' => null, 'msg' => '核验服务暂时连不上，稍后再试。'];
        }
        $j = json_decode((string)$body, true);
        if (!is_array($j)) {
            return ['ok' => false, 'http' => $http, 'json' => null, 'msg' => '核验服务回了一段看不懂的东西（HTTP ' . $http . '）。'];
        }
        if ($http >= 400) {
            return [
                'ok'   => false,
                'http' => $http,
                'json' => $j,
                'msg'  => (string)($j['msg'] ?? '核验服务回了个 HTTP ' . $http . '。'),
            ];
        }
        return ['ok' => true, 'json' => $j, 'http' => $http, 'msg' => ''];
    }
}
