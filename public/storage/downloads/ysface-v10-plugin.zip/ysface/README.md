# Ysface · 魔方 V10 人脸实名核验插件

## 安装

1. 把 `ysface` 整个目录放到 `public/plugins/certification/`。
2. 后台「实名认证 → 接口管理」刷新，安装「人脸活体实名核验」。
3. 配置里填：
   - 接口地址：单人版分发站的站点根，例如 `https://face.example.com`，不要带结尾斜杠。
   - AppID / AppKey：分发站「接口」页签里的那一对（不是上游平台的）。
4. 前台个人实名认证选这个接口即可。

## 流程

- 用户提交姓名/身份证 → 验证页调分发站 `POST /api/v4/face_start`，拿 `order_no` + `verify_url`。
- 页面显示二维码，每 3 秒轮询 `/certification/ysface/index/status?certify_id=...`。
- 轮询调 `POST /api/v4/face_query`（传 `order_no`）；分发站那边活体出图后只调一次人脸核验。
  - HTTP 200 且 `data.passed=1` → 系统状态 1（通过），`refresh=1`
  - HTTP 200 且 `data.passed=0`，或 HTTP `404` / `502` / `504` → 系统状态 2（不通过），`refresh=1`
  - HTTP `503`（结果没出来）/ 连不上 → 系统状态 **2 + `refresh=0`**（V10 验证页只认这个组合继续等）
- 页面里的 `window.isCodeFinshed` 由插件控制：先 false，第一次轮询成功后才 true；不设它，V10 验证页 4 秒后就会当「已提交资料」跳走。
- 轮询地址必须带 `client_id`：V10 的 `/certification/...` 路由**没有登录中间件**，控制器里 `get_client_id()` 恒为 0；官方插件也是从页面把 `client_id` 带过去的。轮询 URL 里带 `&client_id=`，控制器再用客户资料表的 `certify_id` 绑定一次，防止拿别人的单刷自己的认证。
- 轮询请求同时带 `Authorization: Bearer <localStorage.jwt>`（V10 客户中心是 JWT 登录），以后路由加了中间件也不用改。
- 发起阶段就失败（分发站回 `502` / 采集页没拉起来）时，插件直接把认证落成 **2 + refresh=1 失败**，并把原因写进 `auth_fail`；不会再跳到「待审核」。这时去分发站「调用记录」看第 1 步的上游返回。
- 分发站的认证有效期默认 300 秒（后台可配 30–300），到期查询返回 HTTP `504`。

## V10 后台必须确认的两项

- **实名认证 → 设置 → 人工复审 = 0**。开着的话，即使接口返回通过，V10 也会把状态改成 3「待审核」，页面只会显示已提交资料。
- **手机一致性 = 0**。个人认证表单里的手机号是 V10 内置字段（提交接口里是 optional），插件没有加它；留空即可。要彻底不显示这一格，只能改 V10 的 `authentication_person.html`，不属于插件范围。

## 要求

- 魔方 V10，PHP 8.x。
- `curl` 扩展；二维码用内置的 PHP QR Code（LGPL），需要 `gd` 扩展。
- 插件不引用外部 CDN、不加载外部字体/图片。
- 内置 QR 库放在 `certification\ysface\qr` 命名空间，**不和官方 idcsmartali 的全局 `QRcode` 类抢名字**；两个插件可以同时装。

## 说明

- `order_no` 会和当前会话绑定，拿别人的单号刷自己的认证不会生效。
- 刷新页面会继续显示同一张二维码，不会重新发起，也不会重复扣费。
