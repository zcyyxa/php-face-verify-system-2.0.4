<?php
namespace certification\ysface;

use app\common\lib\Plugin;
use certification\ysface\logic\YsfaceLogic;
use think\facade\Db;

/**
 * 人脸活体实名核验（智简魔方 V10 实名认证接口）。
 *
 * 流程：
 *   YsfacePerson() -> 调本站 /api/v4/face_start，拿 order_no + verify_url，出二维码，状态写 4（进行中）
 *   页面轮询       -> /certification/ysface/index/status?certify_id=...
 *   控制器         -> 调本站 /api/v4/face_query：活体通过后本站只调一次 facehy
 *                     data.passed=1 -> 状态 1；data.passed=0 或 404/502/504 -> 状态 2；其余继续等
 *
 * 和财务版一样，刷新/重进固定复用同一张码：会话里存着 active 单，绝不重新发起。
 */
class Ysface extends Plugin
{
    public $info = [
        'name'        => 'Ysface',
        'title'       => '人脸活体实名核验',
        'description' => '手机扫码做一次活体采集，与身份信息比对',
        'status'      => 1,
        'author'      => '云尚API',
        'version'     => '1.1.0',
        'help_url'    => '',
        'description_url' => '',
    ];

    public function install()
    {
        return true;
    }

    public function uninstall()
    {
        return true;
    }

    /**
     * 个人实名认证。$certifi 里是 card_type / name / card。
     * 返回 HTML（V10 的 Person 约定），由系统渲染在实名认证页。
     */
    public function YsfacePerson($certifi)
    {
        $cardType = (int)($certifi['card_type'] ?? 0);
        $name     = trim((string)($certifi['name'] ?? ''));
        $card     = strtoupper(trim((string)($certifi['card'] ?? '')));

        $logic    = new YsfaceLogic();
        $hash     = hash('sha256', $name . "\0" . $card);
        $active   = session('ysface_active');
        $special  = !empty($certifi['special']);
        $clientId = (int)get_client_id();

        if ($cardType !== 1) {
            return $special ? [] : $this->failNotice('只支持身份证认证（证件类型 1）。');
        }
        if ($name === '' || !preg_match('~^\d{17}[\dX]$~', $card)) {
            return $special ? [] : $this->failNotice('姓名或身份证号格式不对。');
        }

        // 同一个人刷新/重进：先问站上这一单到哪一步了，绝不重新发起
        if (is_array($active) && (string)($active['hash'] ?? '') === $hash && (string)($active['order_no'] ?? '') !== '') {
            $order = (string)$active['order_no'];
            $live  = (string)($active['verify_url'] ?? '');
            if ($special && $live !== '') {
                // 特殊流程（系统自己出码、自己轮询 Status）：同一张码，不重新发起
                return ['url' => $live, 'certify_id' => $order];
            }
            $q   = $logic->query($order);
            $v   = $logic->verdict($q);
            $msg = (string)$v['msg'];

            if ($v['state'] === 'pass') {
                $this->hookStatus(1, '');
                $this->clearActive();
                return $this->noticeHtml('认证已通过。');
            }
            if ($v['state'] === 'wait' || $v['state'] === 'error') {
                // 还在采集 / 站上临时故障：同一张码，不重新发起。
                // 系统记录保持在「2 且 refresh=0」，V10 验证页才会继续等。
                if ($live !== '') {
                    $this->hookPendingState($order);
                    return $this->renderQr($name, $card, $order, $live, $clientId);
                }
                return $this->noticeHtml('暂时查不到认证状态，请稍后刷新。', true);
            }
            // fail
            $this->hookStatus(2, $msg !== '' ? $msg : '上一次认证未通过');
            $this->clearActive();
            return $this->noticeHtml('上一次认证未通过，请重新提交认证。', true);
        }

        // 新单
        $r = $logic->start($name, $card);
        if (empty($r['ok'])) {
            if ($special) {
                return [];
            }
            return $this->failNotice((string)($r['msg'] ?? '核验服务暂时不可用，稍后再试。'));
        }

        $order = (string)$r['order_no'];
        $live  = (string)$r['verify_url'];

        session('ysface_active', [
            'hash'       => $hash,
            'order_no'   => $order,
            'verify_url' => $live,
        ]);
        session('ysface_check_id', $order);

        if ($special) {
            return ['url' => $live, 'certify_id' => $order];
        }

        $this->hookPending($order);

        return $this->renderQr($name, $card, $order, $live, $clientId);
    }

    public function YsfaceCompany($certifi)
    {
        return $this->noticeHtml('这个人脸核验接口只支持个人实名认证。', true);
    }

    public function YsfaceCollectionInfo($type)
    {
        return [];
    }

    /**
     * 特殊流程（系统自己出码、自己轮询）用的状态方法。
     * 不写 hook，只把站上的结论翻成 1/2/4。
     */
    public function YsfaceStatus($certify)
    {
        $cid = trim((string)($certify['certify_id'] ?? ''));
        if ($cid === '') {
            return ['status' => 400, 'msg' => '请求错误', 'code' => 4];
        }
        $logic = new YsfaceLogic();
        $v = $logic->verdict($logic->query($cid));
        if ($v['state'] === 'pass') {
            return ['status' => 200, 'msg' => '请求成功', 'code' => 1];
        }
        if ($v['state'] === 'fail') {
            return ['status' => 200, 'msg' => '请求成功', 'code' => 2];
        }
        return ['status' => 200, 'msg' => '请求成功', 'code' => 4];
    }

    /**
     * 后台配置：DB 里的 plugin.config 覆盖 config/config.php 的默认值。
     */
    public function Config()
    {
        $config = Db::name('plugin')->where('name', $this->info['name'])->value('config');
        if (is_string($config) && $config !== '' && $config !== 'null') {
            $config = json_decode($config, true);
        } else {
            $config = [];
        }
        if (!is_array($config)) {
            $config = [];
        }

        $default = require __DIR__ . '/config/config.php';
        if (!is_array($default)) {
            $default = [];
        }

        return array_merge($default, $config);
    }

    private function hookPending(string $checkId): void
    {
        $this->pendingMark($checkId);
        session('ysface_check_id', $checkId);
    }

    private function hookStatus(int $status, string $fail): void
    {
        hook('update_certification_person', [
            'client_id' => (int)get_client_id(),
            'status'    => $status,
            'auth_fail' => $fail,
            'refresh'   => 1,
        ]);
    }

    /**
     * 同一张码还在等：认证日志写 status=2 + refresh=0（验证页继续等），
     * 客户资料表写 status=4（状态页显示待审核，不是未通过）。
     */
    private function hookPendingState(string $checkId): void
    {
        $this->pendingMark($checkId);
    }

    private function pendingMark(string $checkId): void
    {
        $notes = "实名认证方式:人脸活体实名核验;\r\n认证单号:{$checkId};\r\n接口提交时间:" . date('Y-m-d H:i:s') . "\r\n";
        (new YsfaceLogic())->markPending((int)get_client_id(), $checkId, $notes);
    }

    private function clearActive(): void
    {
        session('ysface_active', null);
        session('ysface_check_id', null);
    }

    private function renderQr(string $name, string $card, string $checkId, string $live, int $clientId): string
    {
        // 实名认证路由本身不带登录中间件，控制器里 get_client_id() 恒为 0；
        // 所以 client_id 必须像官方插件一样从这个页面带过去。
        $poll   = '/certification/ysface/index/status?certify_id=' . rawurlencode($checkId)
            . '&type=person&client_id=' . $clientId;
        $pollJs = json_encode($poll, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        $qr = '';
        try {
            // 只在真正要出码的时候才载入 QR 库：插件列表/接口管理只加载入口类，
            // 不能因为这份第三方库把整个后台拖死。
            if (!class_exists('certification\\ysface\\qr\\QRcode')) {
                require_once __DIR__ . '/phpqrcode/phpqrcode.php';
            }
            $resp = \certification\ysface\qr\QRcode::png($live, false, 0, 4, 5, false);
            $png  = (is_object($resp) && method_exists($resp, 'getData')) ? (string)$resp->getData() : '';
            if ($png !== '') {
                $qr = '<img height="200" width="200" src="data:image/png;base64,' . base64_encode($png) . '" alt="人脸认证二维码">';
            }
        } catch (\Throwable $e) {
            $qr = '';
        }
        if ($qr === '') {
            $qr = '<p>二维码没生成出来，用手机打开：<a href="' . $this->h($live) . '" target="_blank" rel="noopener">' . $this->h($live) . '</a></p>';
        }

        $masked = substr($card, 0, 6) . '********' . substr($card, -4);

        return "
        <div class='thirdBox-left'>
            <div class='left-box1'>
                <p><span class='left-title'>认证姓名：</span><span>" . $this->h($name) . "</span></p>
                <p><span class='left-title'>证件号码：</span><span>" . $this->h($masked) . "</span></p>
            </div>
            <div id='contentBox'>" . $qr . "</div>
            <div class='left-box2'>
                <div class='sao-text'>
                    <p>用手机扫描二维码</p>
                    <p>按提示完成活体检测</p>
                </div>
            </div>
        </div>
        <div class='thirdBox-right'>
            <img src='/plugins/addon/idcsmart_certification/template/clientarea/pc/default/img/account/personal_certification.png' alt=''>
        </div>
        <script>
        (function(){
            // V10 的验证页会看这个开关：false 时先等实名接口，true 后才轮询系统状态。
            // 不设它，验证页 4 秒后就会去查系统状态，看到 status=4 直接跳「已提交资料」。
            window.isCodeFinshed = false;
            var url = " . $pollJs . ";
            var jwt = localStorage.getItem('jwt') || '';
            var headers = {'Accept': 'application/json'};
            // V10 客户中心是 JWT 登录，自带的 Axios 会加 Authorization；
            // 原生 fetch 不加这个头，控制器里 get_client_id() 就是 0，状态永远写不回去。
            if (jwt) { headers['Authorization'] = 'Bearer ' + jwt; }
            var timer = setInterval(function(){
                fetch(url, {credentials:'same-origin', headers: headers})
                    .then(function(r){ return r.json(); })
                    .then(function(j){
                        window.isCodeFinshed = true;
                        if (!j) { return; }
                        if (j.code === 1 || j.code === 2) {
                            clearInterval(timer);
                        }
                    })
                    .catch(function(){});
            }, 3000);
        })();
        </script>";
    }

    /**
     * 发起阶段就失败：把系统记录落成正式失败（2 + refresh=1）。
     * 不落的话记录会停在 4，V10 验证页几秒后就把人送去「待审核」。
     */
    private function failNotice(string $msg): string
    {
        $this->hookStatus(2, '人脸实名核验：' . $msg);
        return $this->noticeHtml($msg, true);
    }

    private function noticeHtml(string $msg, bool $isError = false): string
    {
        $cls = $isError ? 'text-danger' : 'text-success';
        return '<h3 class="pt-2 font-weight-bold h2 py-4 ' . $cls . '">' . $this->h($msg) . '</h3>';
    }

    private function h(string $s): string
    {
        return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
