<?php
return [
    'amount' => [
        'title' => '认证金额',
        'type'  => 'text',
        'value' => '0',
        'tip'   => '认证费用，0为免费',
    ],
    'free' => [
        'title' => '免费次数',
        'type'  => 'text',
        'value' => '0',
        'tip'   => '每个用户可免费认证次数',
    ],
    'api_url' => [
        'title' => '接口地址',
        'type'  => 'text',
        'value' => '',
        'tip'   => '你的分发站地址，例 https://abc.com。带二级目录要写全（https://abc.com/face），别带结尾的斜杠',
    ],
    'api_id' => [
        'title' => '密钥 ID',
        'type'  => 'text',
        'value' => '',
        'tip'   => '分发站管理页「接口」页签里的 AppID（调用时放在 X-App-Id）',
    ],
    'api_key' => [
        'title' => '密钥',
        'type'  => 'text',
        'value' => '',
        'tip'   => '密钥本体（调用时放在 X-App-Key）。没存就回管理页重建一把',
    ],
];
