<?php
namespace certification\ysface;

use app\admin\lib\Plugin;
use cmf\phpqrcode\QRcode;

/**
 * 人脸活体实名核验（分发站版）。
 *
 * 计费口径：调用方一旦拿到 H5 采集页（verify_url）就开始计费，所以「重复发起」必须挡住。
 * personal() 每次被系统调用（提交、刷新、重新进入）都先把上一次还活着的单找回来：
 *   - 还在等结果：按配置决定「继续用同一张码」还是「直接作废、要求重新发起」；
 *   - 已经通过/不通过：按真实结论回写，不会把已通过的单误判成失败；
 *   - 查不到状态（分发站临时故障）：只提示，不动单子。
 * 两种模式都不会再调一次 face_start。
 *
 * 1.4 起只走分发站 v4 接口：发起 POST api/v4/face_start（拿 order_no + verify_url），
 * 查询 POST api/v4/face_query（传 order_no）。旧接口已从站上整体下架。
 */
class YsfacePlugin extends Plugin
{
    public $info = [
        'name'        => 'Ysface',
        'title'       => '人脸活体实名核验',
        'description' => '手机扫码做一次活体采集，与身份信息比对',
        'status'      => 1,
        'author'      => '云尚API',
        'version'     => '1.4',
        'help_url'    => 'https://yunsapi.com',
    ];

    const API_FALLBACK = '';
    const CACHE_KEY    = 'ysface_active_order';

    // 同一个请求里 personal() 被系统调两次时不要再当「重新进入」处理
    private static $startedNow = [];

    public function install()
    {
        return true;
    }

    public function uninstall()
    {
        return true;
    }

    public function personal($certifi)
    {
        $name = trim((string)($certifi['name'] ?? ''));
        $card = trim((string)($certifi['card'] ?? ''));
        if ($name === '' || $card === '') {
            return $this->buildNoticeHtml('认证失败', '姓名和身份证号不能为空。', 'danger');
        }

        $hash   = hash('sha256', $name . "\0" . strtoupper($card));
        $reqKey = $hash . '@' . (string)($_SERVER['REQUEST_TIME_FLOAT'] ?? '');
        $active = $this->activeGet();

        // 系统在同一个请求里把 personal() 调了第二次：直接把刚出的码还回去
        if (isset(self::$startedNow[$reqKey])) {
            $now = self::$startedNow[$reqKey];
            return $this->buildQrPage((string)$now['verify_url'], (string)$now['order_no'], true);
        }

        // 同一个人在页面刷新/重新进入：绝不重新发起
        if ($active !== null && (string)($active['hash'] ?? '') === $hash && (string)($active['order_no'] ?? '') !== '') {
            return $this->handleAgain($active);
        }

        // 换了一个人：上一次还挂着的单直接作废，再发起新的
        if ($active !== null && (string)($active['order_no'] ?? '') !== '') {
            $this->closeActive($active, '换成了另一个人认证，上一次作废');
        }

        $r = $this->apiPost('api/v4/face_start', ['name' => $name, 'idcard' => $card]);
        if (empty($r['ok'])) {
            return $this->buildNoticeHtml('认证失败', (string)$r['msg'], 'danger');
        }

        $data  = isset($r['json']['data']) && is_array($r['json']['data']) ? $r['json']['data'] : [];
        $order = trim((string)($data['order_no'] ?? ''));
        $live  = trim((string)($data['verify_url'] ?? ''));
        if ($order === '' || $live === '') {
            return $this->buildNoticeHtml(
                '认证失败',
                (string)($r['json']['msg'] ?? '采集页没拉起来，这一笔不算数，再点一次开始。'),
                'danger'
            );
        }

        // 先把缓存落好，再回写状态：中途出错也不会把自己当成「没发起过」
        $this->activeSet([
            'hash'      => $hash,
            'order_no'  => $order,
            'verify_url' => $live,
        ]);
        updatePersonalCertifiStatus([
            'certify_id' => $order,
            'status'     => 4,
        ]);

        self::$startedNow[$reqKey] = ['order_no' => $order, 'verify_url' => $live];
        return $this->buildQrPage($live, $order, false);
    }

    public function getStatus($certifi)
    {
        $id = trim((string)($certifi['certify_id'] ?? ''));
        if ($id === '') {
            return ['status' => 4, 'msg' => '认证初始化中，请稍候...'];
        }

        $r = $this->apiPost('api/v4/face_query', ['order_no' => $id]);
        $v = $this->verdict($r);

        if ($v['state'] === 'pass') {
            $this->activeClearIf($id);
            return ['status' => 1, 'msg' => $v['msg'] === '' ? '认证通过' : $v['msg']];
        }
        if ($v['state'] === 'fail') {
            $this->activeClearIf($id);
            return ['status' => 2, 'msg' => $v['msg'] === '' ? '认证不通过' : $v['msg']];
        }
        // wait / error 都继续等：分发站临时故障不能把还活着的单写死
        return ['status' => 4, 'msg' => $v['msg'] === '' ? '认证中，请完成人脸采集...' : $v['msg']];
    }

    /**
     * 把 v4 查询结果翻成三种状态：
     *   pass  —— data.passed=1
     *   fail  —— data.passed=0，或这一单已经没法再查（404 单号不存在 / 504 超时 / 502 上游出错）
     *   wait  —— 503 结果没出来
     *   error —— 连不上、服务端回的不认识；保留单子，下一轮再问
     */
    private function verdict(array $r): array
    {
        $http = (int)($r['http'] ?? 0);
        $msg  = trim((string)($r['msg'] ?? ''));

        if (empty($r['ok'])) {
            if ($http === 503) {
                return ['state' => 'wait', 'msg' => $msg === '' ? '认证中，请稍后再查...' : $msg];
            }
            if (in_array($http, [404, 502, 504], true)) {
                return ['state' => 'fail', 'msg' => $msg];
            }
            return ['state' => 'error', 'msg' => $msg];
        }

        $j      = isset($r['json']) && is_array($r['json']) ? $r['json'] : [];
        $data   = isset($j['data']) && is_array($j['data']) ? $j['data'] : [];
        $passed = array_key_exists('passed', $data) ? (int)$data['passed'] : -1;
        $say    = trim((string)($data['message'] ?? ($j['msg'] ?? '')));
        if ($say === '') {
            $say = $msg;
        }
        if ($passed === 1) {
            return ['state' => 'pass', 'msg' => $say];
        }
        if ($passed === 0) {
            return ['state' => 'fail', 'msg' => $say];
        }
        return ['state' => 'wait', 'msg' => $say === '' ? '认证中，请完成人脸采集...' : $say];
    }

    public function collectionInfo()
    {
        return [];
    }

    /**
     * 同一人再次进入（刷新/返回）：先问分发站这一单真实到哪一步了。
     * 查询不收费，也不会把已通过的单误判成失败。
     */
    private function handleAgain(array $active)
    {
        $id   = (string)$active['order_no'];
        $live = (string)($active['verify_url'] ?? '');

        $r = $this->apiPost('api/v4/face_query', ['order_no' => $id]);
        $v = $this->verdict($r);

        if ($v['state'] === 'pass') {
            $this->activeClear();
            updatePersonalCertifiStatus(['certify_id' => $id, 'status' => 1]);
            return $this->buildNoticeHtml('认证已通过', '这次实名认证已经完成。', 'success');
        }
        if ($v['state'] === 'fail') {
            $this->activeClear();
            updatePersonalCertifiStatus([
                'certify_id' => $id,
                'status'     => 2,
                'auth_fail'  => $v['msg'] === '' ? '上一次认证未通过' : $v['msg'],
            ]);
            return $this->buildNoticeHtml('上一次认证未通过', '请返回认证页重新发起。', 'danger');
        }
        if ($v['state'] === 'error') {
            // 查不到 ≠ 已作废。不要因为一次临时故障把还活着的单写死
            return $this->buildNoticeHtml('暂时查不到状态', '请稍后刷新；这一次认证还没有重新发起。', 'warning');
        }

        // 还在等结果：固定继续用同一张码，绝不重新发起
        if ($live !== '') {
            updatePersonalCertifiStatus(['certify_id' => $id, 'status' => 4]);
            return $this->buildQrPage($live, $id, true);
        }
        return $this->buildNoticeHtml('暂时查不到状态', '请稍后刷新；这一次认证还没有重新发起。', 'warning');
    }

    private function closeActive(array $active, string $reason): void
    {
        $id = (string)($active['order_no'] ?? '');
        if ($id !== '') {
            updatePersonalCertifiStatus([
                'certify_id' => $id,
                'status'     => 2,
                'auth_fail'  => $reason,
            ]);
        }
        $this->activeClear();
    }

    private function activeGet(): ?array
    {
        $v = null;
        try {
            if (function_exists('session')) {
                $v = session(self::CACHE_KEY);
            }
        } catch (\Throwable $e) {
            $v = null;
        }
        if (!is_array($v)) {
            $v = $_SESSION[self::CACHE_KEY] ?? null;
        }
        return is_array($v) ? $v : null;
    }

    private function activeSet(array $v): void
    {
        try {
            if (function_exists('session')) {
                session(self::CACHE_KEY, $v);
            }
        } catch (\Throwable $e) {
            // 系统会话不可用时退回原生会话
        }
        $_SESSION[self::CACHE_KEY] = $v;
    }

    private function activeClear(): void
    {
        try {
            if (function_exists('session')) {
                session(self::CACHE_KEY, null);
            }
            if (class_exists('\\think\\facade\\Session')) {
                \think\facade\Session::delete(self::CACHE_KEY);
            }
        } catch (\Throwable $e) {
            // 同上
        }
        unset($_SESSION[self::CACHE_KEY]);
    }

    private function activeClearIf(string $checkId): void
    {
        $v = $this->activeGet();
        if ($v !== null && (string)($v['order_no'] ?? '') === $checkId) {
            $this->activeClear();
        }
    }

    private function apiPost(string $path, array $fields)
    {
        $cfg  = $this->getConfig();
        $base = rtrim(trim((string)($cfg['api_url'] ?? '')), '/');
        if ($base === '') {
            $base = self::API_FALLBACK;
        }
        $kid = trim((string)($cfg['api_id'] ?? ''));
        $key = trim((string)($cfg['api_key'] ?? ''));
        if ($base === '' || $kid === '' || $key === '') {
            return ['ok' => false, 'msg' => '核验服务还没配置好（接口地址 / 密钥），联系管理员。'];
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $base . '/' . $path);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($fields));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/x-www-form-urlencoded',
            'X-App-Id: ' . $kid,
            'X-App-Key: ' . $key,
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // 分发站那边「活体出图 + 实名比对」可能连着打两次上游，留足 30 秒
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 8);

        $body = curl_exec($ch);
        $err  = (string)curl_error($ch);
        $http = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($body === false || $err !== '') {
            return ['ok' => false, 'http' => 0, 'json' => null, 'msg' => '核验服务暂时连不上，稍后再试。'];
        }

        $j = json_decode((string)$body, true);
        if (!is_array($j)) {
            return ['ok' => false, 'http' => $http, 'json' => null, 'msg' => '核验服务回了一段看不懂的东西（HTTP ' . $http . '）。'];
        }
        if ($http >= 400) {
            // 503 是「结果还没出来」，404/504/502 是这一单最终的失败态；
            // 调用方要靠 HTTP 状态分清，所以这里把 http 和 json 一起带出去
            $m = trim((string)($j['msg'] ?? ''));
            return [
                'ok'   => false,
                'http' => $http,
                'json' => $j,
                'msg'  => $m === '' ? '核验服务回了个 HTTP ' . $http . '。' : $m,
            ];
        }

        return ['ok' => true, 'http' => $http, 'json' => $j, 'msg' => ''];
    }

    private function qrBase64(string $text): string
    {
        $tmp = tempnam(sys_get_temp_dir(), 'ysf');
        if ($tmp === false) {
            return '';
        }
        QRcode::png($text, $tmp, QR_ECLEVEL_L, 8, 1);
        $raw = @file_get_contents($tmp);
        @unlink($tmp);

        return ($raw === false || $raw === '') ? '' : base64_encode($raw);
    }

    /**
     * 用系统自带的样式类，不另外塞 <style>。魔方财务前后台用的是 Bootstrap 这套。
     */
    private function buildQrPage(string $live, string $id, bool $again): string
    {
        $u   = $this->h($live);
        $png = $this->qrBase64($live);

        if ($png === '') {
            $body = '<p class="text-muted mb-3">二维码没生成出来。用手机浏览器打开下面这个地址完成认证：</p>'
                . '<p class="mb-3"><a href="' . $u . '" target="_blank" rel="noopener">' . $u . '</a></p>';
        } else {
            $body = '<img src="data:image/png;base64,' . $png . '" class="img-fluid d-block mx-auto mb-3 border rounded" alt="人脸认证二维码">'
                . '<p class="mb-3"><a href="' . $u . '" target="_blank" rel="noopener" class="btn btn-primary">在手机上打开</a></p>';
        }

        $tip = $again
            ? '这是同一次认证，二维码没有变化，请继续扫码。'
            : '刷新本页不会重复发起，请尽快扫码。';

        return '<div class="text-center py-4">'
            . '<h5 class="mb-2">人脸实名认证</h5>'
            . '<p class="text-muted mb-3">用手机扫描二维码，按提示做一次活体检测。</p>'
            . $body
            . '<p class="text-muted small mb-1">认证单号：' . $this->h($id) . '</p>'
            . '<p class="text-muted small mb-0">' . $this->h($tip) . '</p>'
            . '</div>';
    }

    private function buildNoticeHtml(string $title, string $msg, string $tone = 'muted'): string
    {
        $cls = [
            'success' => 'text-success',
            'danger'  => 'text-danger',
            'warning' => 'text-warning',
            'muted'   => 'text-muted',
        ][$tone] ?? 'text-muted';

        return '<div class="text-center py-4">'
            . '<h5 class="mb-2">' . $this->h($title) . '</h5>'
            . '<p class="' . $cls . ' mb-0">' . $this->h($msg) . '</p>'
            . '</div>';
    }

    private function h(string $s): string
    {
        return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
